package com.nomina.udeadvance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UdeadvanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
