package com.nomina.udeadvance.controlador;

public class ControladorMovDinero {
}
