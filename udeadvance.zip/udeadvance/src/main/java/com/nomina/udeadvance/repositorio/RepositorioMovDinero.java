package com.nomina.udeadvance.repositorio;

public interface RepositorioMovDinero {
}
