package com.nomina.udeadvance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UdeadvanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UdeadvanceApplication.class, args);
	}

}
