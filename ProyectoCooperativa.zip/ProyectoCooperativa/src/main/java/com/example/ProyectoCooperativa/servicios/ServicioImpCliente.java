package com.example.ProyectoCooperativa.servicios;

import com.example.ProyectoCooperativa.entidades.Cliente;
import com.example.ProyectoCooperativa.repositorio.RepositorioCliente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

@Service
public class ServicioImpCliente implements ServicioCliente{

    @Autowired
    private RepositorioCliente reposiorioCliente;

    @Override
    public List<Cliente> listarClientes() {
        return reposiorioCliente.findAll();
    }

    @Override
    public Cliente guardarClientes(Cliente cliente) {
        return reposiorioCliente.save(cliente);
    }

    @Override
    public Cliente consultarClientesPorId(Integer documento) {
        return reposiorioCliente.findById(documento).get();
    }

    @Override
    public Cliente actualizarClientes(Cliente cliente) {
        return reposiorioCliente.save(cliente);
    }

    @Override
    public void eliminarClientes(Integer documento) {
        reposiorioCliente.deleteById(documento);
    }

    @Override
    public Cliente actualizarPorId(Integer id, Map<Object, Object> objectMap) {
            Cliente cli = reposiorioCliente.findById(id).get();
            objectMap.forEach((key,value)->{
                Field field = ReflectionUtils.findField(Cliente.class, (String) key);
                field.setAccessible(true);
                ReflectionUtils.setField(field, cli, value);
            });
            return reposiorioCliente.save(cli);
        }
    }


