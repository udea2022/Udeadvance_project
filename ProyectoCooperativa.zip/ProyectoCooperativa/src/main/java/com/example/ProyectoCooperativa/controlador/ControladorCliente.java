package com.example.ProyectoCooperativa.controlador;


import com.example.ProyectoCooperativa.entidades.Cliente;
import com.example.ProyectoCooperativa.servicios.ServicioImpCliente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RequestMapping("/cliente")
@RestController
public class ControladorCliente {
    @Autowired
    private ServicioImpCliente sic;

    @GetMapping
    public List<Cliente> listar(){
        return sic.listarClientes();
    }

    @GetMapping("/{id}")
    public Cliente consultar(@PathVariable("id") Integer id){
        return sic.consultarClientesPorId(id);
    }

    @PostMapping
    public Cliente insertar(@RequestBody Cliente cli){
        return sic.guardarClientes(cli);
    }

    @PutMapping
    public Cliente actualizar(@RequestBody Cliente cli){
        return sic.actualizarClientes(cli);
    }


    @DeleteMapping
    public void eliminar(@RequestBody Cliente cli){
        sic.eliminarClientes(cli.getDocumento());
    }

    @PatchMapping("/{id}")
    public Cliente actualizarpor(@PathVariable("id")Integer id, @RequestBody Map<Object, Object> objectMap){
        return sic.actualizarPorId(id, objectMap);
    }
}
